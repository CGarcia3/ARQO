# arq0_riscv

Repo preliminar RISC V para Arquitectura de ordenadores (arqo) 2022

Código RTL (VHDL) del procesador RISC V unciclo. Implementa un subconjunto del set de instrucciones.

Carpeta SIM con Testbench y modelos de memoria de datos e instrucciones.
El contenido de las memorias se carga desde los ficheros exportados desde el simulador RARS
El fichero runsim_do compila y simula en modelsim/questasim
